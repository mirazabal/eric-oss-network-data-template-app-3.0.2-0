import pytest

from unittest.mock import Mock, patch

from network_data_template_app.message_bus_consumer import (
    MessageBusConsumer,
    fdn_to_pm_counter_status,
    _get_message_bus_connection_details,
)


@pytest.mark.asyncio
async def test_consume_messages_consumes_valid_messages(
    authentication_and_authorization,
    data_management_url,
    data_management_with_data_jobs,
    get_schema_valid_schema,
    message_bus_consumer_consumes_valid_messages,
):
    """Test that `consume_messages()` consumes valid messages."""
    await message_bus_consumer_consumes_valid_messages._consume_messages()
    key = "urn:3gpp:dn:SubNetwork=Europe,SubNetwork=Ireland,MeContext=NR01gNodeBRadio00087,ManagedElement=NR01gNodeBRadio00087,GNBDUFunction=1,NRCellDU=NR01gNodeBRadio00087-1"
    assert key in fdn_to_pm_counter_status
    assert fdn_to_pm_counter_status[key] is True


@pytest.mark.asyncio
async def test_consume_messages_consumes_no_messages(
    authentication_and_authorization,
    data_management_url,
    data_management_with_data_jobs,
    get_schema_valid_schema,
    message_bus_consumer_consumes_no_messages,
):
    """Test that `consume_messages()` consumes no messages."""
    await message_bus_consumer_consumes_no_messages._consume_messages()
    key = "urn:3gpp:dn:SubNetwork=Europe,SubNetwork=Ireland,MeContext=NR01gNodeBRadio00087,ManagedElement=NR01gNodeBRadio00087,GNBDUFunction=1,NRCellDU=NR01gNodeBRadio00087-1"
    assert key in fdn_to_pm_counter_status
    assert fdn_to_pm_counter_status[key] is False


@pytest.mark.asyncio
async def test_consume_messages_raises_system_exit_when_consuming_fatal_message(
    mock_apis, message_bus_consumer_consumes_err_messages
):
    """Test that `consume_messages()` will close the application when consuming a message with a fatal error."""
    with pytest.raises(SystemExit) as exc_info:
        await message_bus_consumer_consumes_err_messages._consume_messages()
        await message_bus_consumer_consumes_err_messages._consume_messages()

    assert exc_info.value.code == 1


@pytest.mark.asyncio
async def test_consume_messages_raises_system_exit_when_interacting_with_kafka(
    mock_apis, message_bus_consumer_with_kafka_exception
):
    """Test that `consume_messages()` will close the application when encountering an exception during any consumer operation."""
    with pytest.raises(SystemExit) as exc_info:
        await message_bus_consumer_with_kafka_exception._consume_messages()
        await message_bus_consumer_with_kafka_exception._consume_messages()

    assert exc_info.value.code == 1


def test_get_token_returns_valid_token(
    mock_apis, message_bus_consumer_consumes_valid_messages
):
    """Test that `get_token()` returns a valid token."""
    with patch(
        "authlib.integrations.httpx_client.OAuth2Client.fetch_token",
        new_callable=Mock,
    ) as mock_fetch_token:
        mock_fetch_token.return_value = {
            "access_token": "2YotnFZFEjr1zCsicMWpAA",
            "token_type": "Bearer",
            "expires_in": 3600,
            "example_parameter": "example_value",
        }
    access_token = message_bus_consumer_consumes_valid_messages._get_token_consumer_client_callback(
        "oauth_cb"
    )
    assert access_token[0] == "2YotnFZFEjr1zCsicMWpAA"


def test_get_message_bus_conn_details_returns_valid_response():
    """Test that `get_message_bus_conn_details()` returns valid message bus connection details."""
    with patch(
        "network_data_template_app.message_bus_consumer.get_message_bus_details",
        new_callable=Mock,
    ) as mock_get_message_bus_details:
        mock_get_message_bus_details.return_value = {
            "topic": "ctr-processed",
            "hosts": ["bootstrap.example.com:443", "bootstrap.example2.com:554", "bootstrap.example3.com:665"]
        }
        message_bus_conn_details = _get_message_bus_connection_details(None)
        assert (message_bus_conn_details["topic"]) == "ctr-processed"
        assert (message_bus_conn_details["hosts"][0]) == "bootstrap.example.com:443"
        assert (message_bus_conn_details["hosts"][1]) == "bootstrap.example2.com:554"
        assert (message_bus_conn_details["hosts"][2]) == "bootstrap.example3.com:665"


def test_format_bootstrap_servers_list(message_bus_conn_details):
    """Test that `_format_bootstrap_servers_list()` returns valid string of bootstrap servers."""
    bootstrap_servers = MessageBusConsumer._format_bootstrap_servers_list(MessageBusConsumer, message_bus_conn_details["hosts"])
    assert (
        bootstrap_servers == "https://example.org:80,https://another.org:8000,https://other.org:1000"
    )
    

def test_get_message_bus_conn_details_raises_exception(
    data_management_api_no_data_jobs,
    sync_oauth_client,
    async_oauth_client,
    kafka_consumer_with_valid_messages,
):
    """Test that the application raises SystemExit when the kafka consumer configuration is invalid."""
    with pytest.raises(SystemExit) as exc_info:
        consumer = MessageBusConsumer(
            sync_oauth_client, async_oauth_client, kafka_consumer_with_valid_messages
        )
        consumer._initialize_consumer()

    assert exc_info.value.code == 1
